#include "prof_accum.h"

alloc_n_gen(0)
