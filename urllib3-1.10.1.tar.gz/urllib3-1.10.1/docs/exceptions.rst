Exceptions
==========

Custom exceptions defined by urllib3

.. automodule:: urllib3.exceptions
    :members:
