.. _glossary:

Glossary
========


.. glossary::

    Zookeeper
        `Apache Zookeeper <http://zookeeper.apache.org/>`_ is a centralized
        service for maintaining configuration information, naming, providing
        distributed synchronization, and providing group services.
