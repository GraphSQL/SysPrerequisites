Configuration
=============

.. automodule :: nose.config
   :members: