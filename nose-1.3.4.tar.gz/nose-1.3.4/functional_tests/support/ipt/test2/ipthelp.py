print "2help imported"

def help(a):
    print "2 help %s" % 1
    pass
