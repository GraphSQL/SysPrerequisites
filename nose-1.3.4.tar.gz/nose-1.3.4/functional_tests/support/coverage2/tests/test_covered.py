import blah
import moo

def test_blah():
    blah.dostuff()

def test_moo():
    moo.dostuff()
