#from . import counter
from time import sleep
#_multiprocess_can_split_ = True
class Test1(object):
    def test1(self):
        sleep(1)
        pass
class Test2(object):
    def test2(self):
        sleep(1)
        pass
